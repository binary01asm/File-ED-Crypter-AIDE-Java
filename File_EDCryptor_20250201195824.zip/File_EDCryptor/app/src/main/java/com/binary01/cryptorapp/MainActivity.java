package com.binary01.cryptorapp;
 
import android.app.Activity;
import android.os.Bundle;
import android.util.Base64;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import android.util.Log;
import android.widget.*;
import android.widget.EditText;
import android.widget.Button;
import android.widget.LinearLayout;
import android.view.View.OnClickListener;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.os.Build;
import android.content.pm.*;
import android.content.pm.*;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.Manifest;
import android.widget.Toast;
import android.graphics.Typeface;
import android.graphics.Color;
import android.content.*;
import android.content.Context;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.graphics.drawable.GradientDrawable;
import android.widget.ScrollView;

public class MainActivity extends Activity {

    private String error;
    private static final int REQUEST_EXTERNAL_STORAGE=1;
    private LinearLayout LinearMain;
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
	
        LinearMain = findViewById(R.id.activitymainLinearLayout1);
      // Here I define a LayoutParams for Widget Layouts---!
      final LinearLayout.LayoutParams paramsX= new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT,android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        paramsX.setMargins((int) 10, (int) 10, (int) 10, (int) 10);
      final LinearLayout.LayoutParams paramsY= new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT,android.widget.LinearLayout.LayoutParams.MATCH_PARENT);
        paramsY.setMargins((int) 10, (int) 10, (int) 10, (int) 10);
     // LayoutParams Code Completed ----!
     
      final ScrollView scrollView= new ScrollView(MainActivity.this);
   //   LinearMain.addView(scrollView,paramsY);
      
      final  LinearLayout linear1 = new LinearLayout(MainActivity.this);
        linear1.setOrientation(1);
        linear1.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.TOP);
        linear1.setBackgroundColor(0xFFF2FFE4);
        
        scrollView.addView(linear1,paramsY);
              
     final EditText edittext_input = new EditText(MainActivity.this);
	    edittext_input.setHint((new Object() {
								   int t;
								   public String toString() {
									   byte[] buf = new byte[18];
									   t = 1914842424;
									   buf[0] = (byte) (t >>> 11);
									   t = 560898229;
									   buf[1] = (byte) (t >>> 16);
									   t = 658656160;
									   buf[2] = (byte) (t >>> 20);
									   t = 607573398;
									   buf[3] = (byte) (t >>> 2);
									   t = 639302089;
									   buf[4] = (byte) (t >>> 2);
									   t = 1328099770;
									   buf[5] = (byte) (t >>> 13);
									   t = 507174346;
									   buf[6] = (byte) (t >>> 9);
									   t = 1908605279;
									   buf[7] = (byte) (t >>> 18);
									   t = -1164391242;
									   buf[8] = (byte) (t >>> 23);
									   t = 967679247;
									   buf[9] = (byte) (t >>> 6);
									   t = -527605193;
									   buf[10] = (byte) (t >>> 17);
									   t = 1341838169;
									   buf[11] = (byte) (t >>> 9);
									   t = 1020844041;
									   buf[12] = (byte) (t >>> 17);
									   t = -1397837643;
									   buf[13] = (byte) (t >>> 21);
									   t = 2033330264;
									   buf[14] = (byte) (t >>> 7);
									   t = 73681957;
									   buf[15] = (byte) (t >>> 5);
									   t = 1403341828;
									   buf[16] = (byte) (t >>> 19);
									   t = -1681177833;
									   buf[17] = (byte) (t >>> 11);
									   return new String(buf);
								   }
							   }.toString()));
     //   edittext_input.setHint("EnterInputFilePath");
        edittext_input.setHintTextColor(0xffffffff);
        edittext_input.setTypeface(Typeface.MONOSPACE,1);
        edittext_input.setShadowLayer(3,4,3, Color.GRAY);
        edittext_input.setTextSize(18);
        linear1.addView(edittext_input,paramsX);
        
     final EditText edittext_output = new EditText(MainActivity.this);
	    edittext_output.setHint((new Object() {
									int t;
									public String toString() {
										byte[] buf = new byte[17];
										t = 341718393;
										buf[0] = (byte) (t >>> 20);
										t = 1363262004;
										buf[1] = (byte) (t >>> 10);
										t = -1367149601;
										buf[2] = (byte) (t >>> 21);
										t = 28871863;
										buf[3] = (byte) (t >>> 5);
										t = -1615385948;
										buf[4] = (byte) (t >>> 12);
										t = 2049411940;
										buf[5] = (byte) (t >>> 15);
										t = -1218933835;
										buf[6] = (byte) (t >>> 20);
										t = 1460106307;
										buf[7] = (byte) (t >>> 8);
										t = 997245858;
										buf[8] = (byte) (t >>> 16);
										t = 195805218;
										buf[9] = (byte) (t >>> 19);
										t = 893023926;
										buf[10] = (byte) (t >>> 15);
										t = -2096779124;
										buf[11] = (byte) (t >>> 1);
										t = 47971143;
										buf[12] = (byte) (t >>> 14);
										t = 964587898;
										buf[13] = (byte) (t >>> 23);
										t = -613817008;
										buf[14] = (byte) (t >>> 19);
										t = 1823533001;
										buf[15] = (byte) (t >>> 15);
										t = -2133938532;
										buf[16] = (byte) (t >>> 5);
										return new String(buf);
									}
								}.toString()));
        //edittext_output.setHint("EnterOutputFormat");
        edittext_output.setHintTextColor(0xffffffff);
        edittext_output.setTypeface(Typeface.MONOSPACE,1);
        edittext_output.setShadowLayer(3,4,3,Color.GRAY);
        edittext_output.setTextSize(18);
        linear1.addView(edittext_output,paramsX);
        
     final Button button1 = new Button(MainActivity.this);
		button1.setHint((new Object() {
							int t;
							public String toString() {
								byte[] buf = new byte[12];
								t = 591725372;
								buf[0] = (byte) (t >>> 23);
								t = -1831674808;
								buf[1] = (byte) (t >>> 17);
								t = 810872199;
								buf[2] = (byte) (t >>> 5);
								t = 1425812671;
								buf[3] = (byte) (t >>> 5);
								t = 2057482911;
								buf[4] = (byte) (t >>> 19);
								t = -319458882;
								buf[5] = (byte) (t >>> 2);
								t = 395829512;
								buf[6] = (byte) (t >>> 2);
								t = -199653619;
								buf[7] = (byte) (t >>> 10);
								t = -88414688;
								buf[8] = (byte) (t >>> 9);
								t = -179525528;
								buf[9] = (byte) (t >>> 13);
								t = 226809283;
								buf[10] = (byte) (t >>> 22);
								t = 395032997;
								buf[11] = (byte) (t >>> 3);
								return new String(buf);
							}
						}.toString()));
        //button1.setHint("FileToBase64");
        button1.setHintTextColor(0xffffffff);
        button1.setTypeface(Typeface.MONOSPACE,1);
        button1.setShadowLayer(3,4,3,Color.GRAY);
        button1.setTextSize(12);
        button1.setBackgroundColor(0xffffffff);
        button1.setElevation(9);
        button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)9, 0xFFE6EEFF));
        linear1.addView(button1,paramsX);
     final Button button2 = new Button(MainActivity.this);
	    button2.setHint((new Object() {
							int t;
							public String toString() {
								byte[] buf = new byte[12];
								t = -1273984223;
								buf[0] = (byte) (t >>> 14);
								t = -1201263860;
								buf[1] = (byte) (t >>> 3);
								t = 1149495015;
								buf[2] = (byte) (t >>> 1);
								t = 1449492052;
								buf[3] = (byte) (t >>> 16);
								t = -2032243853;
								buf[4] = (byte) (t >>> 21);
								t = 110995283;
								buf[5] = (byte) (t >>> 21);
								t = 952216148;
								buf[6] = (byte) (t >>> 7);
								t = -592103532;
								buf[7] = (byte) (t >>> 7);
								t = 1430685656;
								buf[8] = (byte) (t >>> 16);
								t = -777704555;
								buf[9] = (byte) (t >>> 18);
								t = -220803926;
								buf[10] = (byte) (t >>> 12);
								t = -95603118;
								buf[11] = (byte) (t >>> 4);
								return new String(buf);
							}
						}.toString())); 
	    //button2.setHint("Base64ToFile");
        button2.setHintTextColor(0xffffffff);
        button2.setTypeface(Typeface.MONOSPACE,1);
        button2.setShadowLayer(3,4,3,Color.GRAY);
        button2.setTextSize(12);
        button2.setBackgroundColor(0xffffffff);
        button2.setElevation(9);
        button2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)9, 0xFFE6EEFF));
        linear1.addView(button2,paramsX);
  
        setContentView(scrollView);
        // setContentView(int resId); Or setContentView(View view); -------!>
        // This is Type of Direct Display On ScreenContent ----!>
        
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_EXTERNAL_STORAGE);
        }
    


		
		button1.setOnClickListener(new View.OnClickListener(){
		@Override
		public void onClick(View v){
		
        	_Base64encoder(edittext_input.getText().toString(), edittext_input.getText().toString().concat(edittext_output.getText().toString()));    
        }});
        
        button2.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){

            _Base64decoder(edittext_input.getText().toString(), edittext_input.getText().toString().concat(edittext_output.getText().toString()));
        }});
    }

    // Method to convert input file to Base64 and write to output file
    public void _Base64encoder(final String _input, final String _output) {
        String filePath = _input; // Input file path
        String base64FilePath = _output; // Output file path
		String ¥ = new String(new byte[]{83,117,99,99,101,115,115,102,117,108,33,});
        try {
            File file = new File(filePath);
            FileInputStream fileInputStream = new FileInputStream(file);
            byte[] fileBytes = new byte[(int) file.length()];
            fileInputStream.read(fileBytes);
            fileInputStream.close();

            /* 1st method   //  byte[] base64String = Base64.getEncoder().encode(fileBytes); */
            byte[] base64String = android.util.Base64.encode(fileBytes, android.util.Base64.DEFAULT);
            FileOutputStream fileOutputStream = new FileOutputStream(base64FilePath);
            fileOutputStream.write(base64String);
            fileOutputStream.close();
            // SketchwareUtil.showMessage(getApplicationContext(), "Successfully!");
            Toast.makeText(getApplication(),¥, Toast.LENGTH_SHORT).show();

            System.out.println("File converted to Base64 File and saved to " + base64FilePath);
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("Error: ", e.toString()); // $$$e.printStackTrace$$$ changed to $$$Log.e("Error: ", e.toString());$$$
            error = e.toString();
            Toast.makeText(getApplication(),error, Toast.LENGTH_SHORT).show();
        }
    }

// Method to convert input Base64 to File and write to output file
    public void _Base64decoder(final String _input, final String _output) {
        String filePath = _input; // Input file path
        String base64FilePath = _output; // Output file path
		String ¥ = new String(new byte[]{83,117,99,99,101,115,115,102,117,108,33,});
        try {
            File file = new File(filePath);
            FileInputStream fileInputStream = new FileInputStream(file);
            byte[] fileBytes = new byte[(int) file.length()];
            fileInputStream.read(fileBytes);
            fileInputStream.close();


            /* 1st method // byte[] base64String = Base64.getDecoder().decode(fileBytes); */

            byte[] base64String = android.util.Base64.decode(fileBytes, android.util.Base64.DEFAULT);

            FileOutputStream fileOutputStream = new FileOutputStream(base64FilePath);
            fileOutputStream.write(base64String);
            fileOutputStream.close();
            // SketchwareUtil.showMessage(getApplicationContext(), "Successfully!");
               Toast.makeText(getApplication(),¥, Toast.LENGTH_SHORT).show();

            System.out.println("Base64 File converted to File and saved to " + base64FilePath);
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("Error: ", e.toString()); // $$$e.printStackTrace$$$ changed to $$$Log.e("Error: ", e.toString());$$$
            error = e.toString();
            Toast.makeText(getApplication(),error, Toast.LENGTH_SHORT).show();
        }
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		String ¥ = new String(new byte[]{83,116,111,114,97,103,101,32,80,101,114,109,105,115,115,105,111,110,});
        if (requestCode == REQUEST_EXTERNAL_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                Toast.makeText(getApplication(),¥+" granted", Toast.LENGTH_SHORT).show();
            } else {
                // Permission denied
                Toast.makeText(getApplication(),¥+" denied", Toast.LENGTH_SHORT).show();
            }
        }
    
  } 
}

